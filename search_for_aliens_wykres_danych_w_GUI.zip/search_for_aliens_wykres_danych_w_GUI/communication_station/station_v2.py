# communication_station/station_v2.py
import asyncio
import tkinter as tk
from tkinter import ttk, scrolledtext
from communication_station.connection_handler import ConnectionHandler
import matplotlib.pyplot as plt

class CommunicationStation:

    def __init__(self, host, port, data_processor, data_storage, root):
        self.host = host
        self.port = port
        self.data_processor = data_processor
        self.data_storage = data_storage
        self.root = root
        self.server = None  # Zmienna przechowująca obiekt serwera
        self.setup_gui()
        
    def setup_gui(self):
        self.messages_text = scrolledtext.ScrolledText(self.root, width=70, height=10)
        self.messages_text.pack(pady=10)

        ttk.Button(self.root, text="Start Server", command=lambda: asyncio.create_task(self.start_server())).pack(pady=10)
        ttk.Button(self.root, text="Stop Server", command=lambda: asyncio.create_task(self.stop_server())).pack(pady=10)

        self.plot_buttons_frame = ttk.Frame(self.root)
        self.plot_buttons_frame.pack(pady=10)

        for i in range(10):
            button = ttk.Button(self.plot_buttons_frame, text=f"Probe {i}", command=lambda i=i: asyncio.create_task(self.fetch_and_plot_temperatures(f"Probe{i}")))
            button.grid(row=0, column=i)

    async def start_server(self):
        print(f"Starting server on {self.host}:{self.port}")
        self.server = await asyncio.start_server(self.handle_connection, self.host, self.port)
        async with self.server:
            print(f"Serving on {self.server.sockets[0].getsockname()}")
            self.messages_text.insert(tk.END, "Server has been started.\n")
            await self.server.serve_forever()

    async def stop_server(self):
        if self.server:
            self.server.close()  # Zamknięcie serwera
            await self.server.wait_closed()  # Oczekiwanie na zamknięcie serwera
            print("Server has been stopped.")
            self.messages_text.insert(tk.END, "Server has been stopped.\n")

    async def handle_connection(self, reader, writer):
        handler = ConnectionHandler(reader, writer, self.data_processor, self.data_storage)
        await handler.process_connection()

    async def fetch_and_plot_temperatures(self, probe_id):
        try:
            temperatures = await self.data_storage.get_probe_temperatures(probe_id)
            if temperatures:
                # Sortowanie i wybieranie 5 najnowszych danych
                temperatures = sorted(temperatures, key=lambda x: x['data_wys'], reverse=True)[:5]
                timestamps = [record['data_wys'] for record in temperatures]
                temp_values = [record['temperature'] for record in temperatures]
                plt.figure(figsize=(10, 5))
                plt.plot(timestamps, temp_values, marker='o', color='red')  # Wykres koloru czerwonego
                plt.title(f"Temperature Data for {probe_id}")
                plt.xlabel("Timestamp")
                plt.ylabel("Temperature (°C)")
                plt.grid(True)
                plt.show()
            else:
                self.messages_text.insert(tk.END, f"No temperature data found for {probe_id}.\n")
        except Exception as e:
            print(f"Error fetching data for {probe_id}: {e}")
            self.messages_text.insert(tk.END, f"Error fetching data for {probe_id}: {e}\n")
