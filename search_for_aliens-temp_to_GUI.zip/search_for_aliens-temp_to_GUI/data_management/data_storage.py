# data_management/data_storage.py
import asyncpg

class DataStorage:
    def __init__(self):
        self.dsn = 'postgresql://postgres:postgres@localhost:5433/zdjecia'

    async def connect(self):
        self.conn = await asyncpg.connect(dsn=self.dsn)

    async def save_temperature(self, probe_id, temperature):
        try:
            query = "INSERT INTO temperatures (probe_id, temperature) VALUES ($1, $2)"
            await self.conn.execute(query, probe_id, temperature)
            print("Temperature data saved successfully.")
        finally:
            pass

    async def get_last_temperature(self):
        query = "SELECT probe_id, temperature, data_wys FROM temperatures ORDER BY data_wys DESC LIMIT 1"
        result = await self.conn.fetchrow(query)
        return result

