class ConnectionHandler:
    def __init__(self, reader, writer, data_processor, data_storage):
        self.reader = reader
        self.writer = writer
        self.data_processor = data_processor
        self.data_storage = data_storage

    async def process_connection(self):
        addr = self.writer.get_extra_info('peername')
        data = await self.reader.read(10000)  # Zwiększono rozmiar bufora
        print(f"Received data from {addr}")
        probe_id, temperature = self.data_processor.extract_metadata(data)
        
        if self.data_processor.verify_data(data):
            await self.data_storage.save_temperature(probe_id, temperature)
        
        self.writer.close()



