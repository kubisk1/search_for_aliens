import asyncio
import random

class ProbeSimulator:
    def __init__(self, probe_id, station_address):
        self.probe_id = probe_id
        self.station_address = station_address

    async def start_communication(self):
        while True:
            try:
                await asyncio.sleep(random.randint(10, 30))  # Symulacja okna komunikacyjnego
                temperature = self.generate_temperature()
                await self.send_data(temperature)
            except asyncio.CancelledError:
                print(f"[{self.probe_id}] Communication task was cancelled.")
                break

    def generate_temperature(self):
        # Generowanie losowej temperatury w zakresie -100 do 100 stopni Celsjusza
        temperature = random.uniform(-100, 100)
        print(f"[{self.probe_id}] Sending temperature: {temperature:.2f}")
        return temperature

    async def send_data(self, temperature):
        reader, writer = await asyncio.open_connection(*self.station_address)
        data = f"{self.probe_id},{temperature}".encode()
        print(f"[{self.probe_id}] Sending data: {data}")
        writer.write(data)
        await writer.drain()
        writer.close()
        await writer.wait_closed()
        print(f"[{self.probe_id}] Data sent successfully.")



