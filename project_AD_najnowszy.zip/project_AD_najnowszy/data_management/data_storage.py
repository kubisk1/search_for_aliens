import asyncpg

class DataStorage:
    def __init__(self, dsn):
        self.dsn = dsn

    async def connect(self):
        self.conn = await asyncpg.connect(dsn=self.dsn)  # Nawiązanie połączenia z bazą danych

    async def save_reading(self, data):
        conn = await asyncpg.connect(dsn=self.dsn)
        try:
            sensor_id = await self.get_sensor_id(data['probe_id'])
            if sensor_id is None:
                raise ValueError(f"Sensor ID for probe {data['probe_id']} not found.")
            query = """
            INSERT INTO readings (sensor_id, timestamp, temperature, humidity, visibility, passengers_count, pressure) 
            VALUES ($1, NOW(), $2, $3, $4, $5, $6)
            """
            await conn.execute(query, sensor_id, data['temperature'], data['humidity'], data['visibility'], data['passengers_count'], data['pressure'])
            print("Reading data saved successfully.")
        finally:
            await conn.close()

    async def get_sensor_id(self, probe_id):
        conn = await asyncpg.connect(dsn=self.dsn)
        try:
            query = "SELECT id FROM sensors WHERE probe_id = $1"
            result = await conn.fetchrow(query, probe_id)
            if result:
                return result['id']
            return None
        finally:
            await conn.close()

    async def get_probe_readings(self, sensor_id):
        conn = await asyncpg.connect(dsn=self.dsn)
        try:
            query = "SELECT timestamp, temperature, humidity, visibility, passengers_count, pressure FROM readings WHERE sensor_id = $1 ORDER BY timestamp"
            results = await conn.fetch(query, sensor_id)
            return results
        finally:
            await conn.close()

    async def save_command(self, station_id, probe_id, command):
        conn = await asyncpg.connect(dsn=self.dsn)
        try:
            query = """
            INSERT INTO commands (station_id, probe_id, command, timestamp) 
            VALUES ($1, $2, $3, NOW())
            """
            await conn.execute(query, station_id, probe_id, command)
            print("Command data saved successfully.")
        finally:
            await conn.close()








